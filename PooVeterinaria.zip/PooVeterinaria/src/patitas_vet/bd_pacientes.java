package patitas_vet;

import javax.swing.table.DefaultTableModel;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class bd_pacientes extends javax.swing.JFrame {
    
    ConnectToServer conexion = new ConnectToServer();
    
    public bd_pacientes() {
        initComponents();
        
        try{
            conexion.conectaSql();
            cargarPacientesEnTabla();
        } catch (Exception e){
            JOptionPane.showMessageDialog(this, "Error al conectar o cargar pacientes: " + e.getMessage());
        }
    }
   
    private void cargarPacientesEnTabla() {
         
         String consulta = "SELECT * FROM Paciente";
         try{
            ResultSet rs = conexion.querySql(consulta);
            ResultSetMetaData metaData = rs.getMetaData();
            int columnas = metaData.getColumnCount();
            
            //para que no sea editable
            DefaultTableModel modelo = new DefaultTableModel(){
              @Override
              public boolean isCellEditable(int row, int column){
                  return false;
              }
            };
            
            //agregar los nombres a las columnas
            for (int i = 1; i <= columnas; i++) {
                modelo.addColumn(metaData.getColumnLabel(i));
            }
            
            //agregar los nombres a las filas
            while (rs.next()) {
                Object[] fila = new Object[columnas];
                for (int i = 0; i < columnas; i++) {
                    fila[i] = rs.getObject(i + 1);
                }
                modelo.addRow(fila);
            }

            tablaPacientes.setModel(modelo);
            
            //para que no se muevan las columnas
            tablaPacientes.getTableHeader().setReorderingAllowed(false);
            
         }catch (SQLException ex){
                JOptionPane.showMessageDialog(this, "Error al cargar la tabla: " + ex.getMessage());
         }
         
     }
    
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPanel1 = new javax.swing.JScrollPane();
        tablaPacientes = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        btnSeleccionar = new javax.swing.JButton();
        btnCerrar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        tablaPacientes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPanel1.setViewportView(tablaPacientes);

        jPanel1.setBackground(new java.awt.Color(109, 151, 115));

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Base de Datos de los Pacientes");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 434, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        btnSeleccionar.setBackground(new java.awt.Color(250, 230, 200));
        btnSeleccionar.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        btnSeleccionar.setForeground(new java.awt.Color(110, 150, 115));
        btnSeleccionar.setText("Seleccionar");
        btnSeleccionar.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        btnSeleccionar.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        btnSeleccionar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSeleccionarActionPerformed(evt);
            }
        });

        btnCerrar.setBackground(new java.awt.Color(250, 230, 200));
        btnCerrar.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        btnCerrar.setForeground(new java.awt.Color(110, 150, 115));
        btnCerrar.setText("Cerrar");
        btnCerrar.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        btnCerrar.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        btnCerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCerrarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jScrollPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1395, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(37, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnSeleccionar, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnCerrar, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 501, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnCerrar, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSeleccionar, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private registros_pacientes ventanaRegistro;
    
    private void btnSeleccionarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeleccionarActionPerformed

        //obtenemos la fila seleccionada
        int fila = tablaPacientes.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Por favor selecciona una fila.");
            return;
        }  
        
        //Extraccion segura de datos
        String nombre = getSafeString(tablaPacientes.getValueAt(fila, 3));
        String apellidos = getSafeString(tablaPacientes.getValueAt(fila, 4));
        String fechaNac = getSafeString(tablaPacientes.getValueAt(fila, 6));
        String sexo = getSafeString(tablaPacientes.getValueAt(fila, 8));
        String color = getSafeString(tablaPacientes.getValueAt(fila, 9));
        //Extraer valores de la fila seleccionada
        
        boolean esterilizado = getSafeBoolean(tablaPacientes.getValueAt(fila, 10));
        double longitud = getSafeDouble(tablaPacientes.getValueAt(fila, 11));
        double altura = getSafeDouble(tablaPacientes.getValueAt(fila, 12));
        double peso = getSafeDouble(tablaPacientes.getValueAt(fila, 13));

        String morfologia = getSafeString(tablaPacientes.getValueAt(fila, 14));
        String grupoSang = getSafeString(tablaPacientes.getValueAt(fila, 15));
        boolean microchip = getSafeBoolean(tablaPacientes.getValueAt(fila, 16));
        boolean tatuaje = getSafeBoolean(tablaPacientes.getValueAt(fila, 17));

        String idTitular = getSafeString(tablaPacientes.getValueAt(fila, 2)); // ID_titular
        String observaciones = getSafeString(tablaPacientes.getValueAt(fila, 18));
       
        
        if (ventanaRegistro == null || !ventanaRegistro.isVisible()) {
            ventanaRegistro = new registros_pacientes();
        }
        
        ventanaRegistro.setNombrePaciente(nombre);
        ventanaRegistro.setApellidPaciente(apellidos);
        ventanaRegistro.setFechaNacimiento(fechaNac);
        ventanaRegistro.setSexo(sexo);
        ventanaRegistro.setColor(color);
        ventanaRegistro.setEsterilizado(esterilizado);
        ventanaRegistro.setLongitud(longitud);
        ventanaRegistro.setAltura(altura);
        ventanaRegistro.setPeso(peso);
        ventanaRegistro.setMorfologia(morfologia);
        ventanaRegistro.setGrupoSanguineo(grupoSang);
        ventanaRegistro.setMicrochip(microchip);
        ventanaRegistro.setIDTitular(idTitular);
        ventanaRegistro.setObservaciones(observaciones); 
        ventanaRegistro.setTatuaje(tatuaje); // si tienes método setTatuaje       
        
        // Muestra la ventana de registro
        ventanaRegistro.setLocationRelativeTo(null);
        ventanaRegistro.setVisible(true);
        
        
    }//GEN-LAST:event_btnSeleccionarActionPerformed

    private void btnCerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCerrarActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnCerrarActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(bd_pacientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(bd_pacientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(bd_pacientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(bd_pacientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new bd_pacientes().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCerrar;
    private javax.swing.JButton btnSeleccionar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPanel1;
    private javax.swing.JTable tablaPacientes;
    // End of variables declaration//GEN-END:variables

    private String getSafeString(Object value) {
        return (value != null) ? String.valueOf(value) : "";
    }

    private boolean getSafeBoolean(Object value) {
        try {
            return Boolean.parseBoolean(String.valueOf(value));
        } catch (Exception e) {
            return false;
        }
    }

    private double getSafeDouble(Object value) {
        try {
            return Double.parseDouble(String.valueOf(value));
        } catch (NumberFormatException e) {
            return 0.0;
        }
    }
}
